const Settings = () => <div className="card"><h1 className="text-2xl text-white">Configurações</h1></div>;
export default Settings;