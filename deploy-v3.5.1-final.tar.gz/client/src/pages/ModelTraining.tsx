const ModelTraining = () => <div className="card"><h1 className="text-2xl text-white">Treinamento de Modelos</h1></div>;
export default ModelTraining;